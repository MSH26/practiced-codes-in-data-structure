#include<iostream>
using namespace std;

struct node{
    int item;
    node* left;
    node* right;

    node(int item){
        this->item = item;
        this->left = NULL;
        this->right = NULL;
    }
};

class BSTtree{
    node* root;
    int count;
public:
    BSTtree(){
        root = NULL;
    }
    void insert(int item){
        node* n = new node(item);
        if(root==NULL){
            root = n;
        }
        else{
            node* tmp = root;
            while(item){

                if(tmp->item >= item){
                    if(tmp->left == NULL){
                        tmp->left = n;
                        break;
                    }
                    else{
                        tmp = tmp->left;
                    }
                }
                else{
                    if(tmp->right == NULL){
                        tmp->right = n;
                        break;
                    }
                    else{
                        tmp = tmp->right;
                    }
                }
            }
        }
    }

    node* getNode(int item){
        node* tmp = root;
        if(tmp->item == item){
            return tmp;
        }
        else if(tmp->item != item){
            while(item){
                if(tmp->item > item){
                    if(tmp->left->item == item){
                        return tmp;
                    }
                    else{
                        tmp = tmp->left;
                    }
                }
                else if(tmp->item < item){
                    if(tmp->right->item == item){
                        return tmp;
                    }
                    else{
                        tmp = tmp->right;
                    }
                }
                else{
                    return tmp;
                }
            }
        }
    }

    void remove(int node){
         node* tmp1 = getNode(node);
         node* tmp = tmp1->right;
         while(tmp->left!=NULL){
            tmp = tmp->left;
         }
         tmp->right = tmp1->right;
         tmp->left = tmp1->left;

    }

    void inorder(node* tmp){
        if(tmp->left != NULL){
            inorder(tmp->left);
        }

        cout<<tmp->item<<" ";

        if(tmp->right != NULL){
            inorder(tmp->right);
        }
    }

    void display(){
        cout<<"The inderorder of the tree "<<endl;
        inorder(root);
    }
};

int main(){
    BSTtree tree;

    int numberOfNode , node;

    cin>>numberOfNode;

    for(int i=0;i<numberOfNode;i++){
        cin>>node;
        tree.insert(node);
    }

    tree.display();
/*
    cin>>node;

    //tree.search(node);
 /*   if(tree.search(node)==true){
        cout<<" COOL!!! "<<endl;
    }
*/
    return 0;
}
